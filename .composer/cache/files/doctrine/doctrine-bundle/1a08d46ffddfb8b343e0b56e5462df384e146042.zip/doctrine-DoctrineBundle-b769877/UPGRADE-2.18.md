UPGRADE FROM 2.17 to 2.18
=========================

DoctrineOrmMappingsPass
-----------------------

### The `DoctrineOrmMappingsPass::createYamlMappingDriver()` method is deprecated

This method is deprecated with no replacement planned and will be removed in
DoctrineBundle 3.0.

### The `DoctrineOrmMappingsPass::createAnnotationMappingDriver()` method is deprecated

This method is deprecated with no replacement planned and will be removed in
DoctrineBundle 3.0.
