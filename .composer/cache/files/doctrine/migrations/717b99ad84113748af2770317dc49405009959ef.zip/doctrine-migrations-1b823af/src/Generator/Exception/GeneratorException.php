<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Generator\Exception;

use Doctrine\Migrations\Exception\MigrationException;

interface GeneratorException extends MigrationException
{
}
