<?php

return [
    'Names' => [
        'ZAR' => [
            'R',
            'South African Rand',
        ],
    ],
];
