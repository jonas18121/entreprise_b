<?php

return [
    'Names' => [
        'USD' => [
            '$',
            'US Dollar',
        ],
        'VEF' => [
            'VEF',
            'Venezuelan Bolívar',
        ],
        'VES' => [
            'VES',
            'VES',
        ],
    ],
];
