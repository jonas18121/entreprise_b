<?php

return [
    'Names' => [
        'PHP' => [
            '₱',
            'peso filipino',
        ],
    ],
];
