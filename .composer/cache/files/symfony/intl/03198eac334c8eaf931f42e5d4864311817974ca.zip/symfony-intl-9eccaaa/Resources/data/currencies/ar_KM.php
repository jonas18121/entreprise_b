<?php

return [
    'Names' => [
        'KMF' => [
            'CF',
            'فرنك جزر القمر',
        ],
    ],
];
