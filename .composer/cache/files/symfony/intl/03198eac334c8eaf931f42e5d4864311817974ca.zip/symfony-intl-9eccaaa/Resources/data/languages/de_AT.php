<?php

return [
    'Names' => [
        'car' => 'karibische Sprache',
        'chb' => 'Chibcha-Sprache',
        'del' => 'Delawarisch',
        'fur' => 'Friulanisch',
        'ha' => 'Hausa',
        'haw' => 'Hawaiianisch',
        'hmn' => 'Miao-Sprache',
        'mus' => 'Muskogee-Sprache',
        'niu' => 'Niueanisch',
        'pag' => 'Pangasinensisch',
        'sh' => 'Serbokroatisch',
        'szl' => 'Schlesisch',
    ],
    'LocalizedNames' => [
        'ar_001' => 'modernes Hocharabisch',
    ],
];
