<?php

return [
    'Names' => [
        'NIO' => [
            'C$',
            'córdoba nicaragüense',
        ],
    ],
];
