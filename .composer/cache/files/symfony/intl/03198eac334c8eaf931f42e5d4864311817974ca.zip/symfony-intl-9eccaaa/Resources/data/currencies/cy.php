<?php

return [
    'Names' => [
        'AED' => [
            'AED',
            'Dirham Yr Emiradau Arabaidd Unedig',
        ],
        'AFA' => [
            'AFA',
            'Afghani Afghanistan (1927–2002)',
        ],
        'AFN' => [
            'AFN',
            'Afghani Afghanistan',
        ],
        'ALL' => [
            'ALL',
            'Lek Albania',
        ],
        'AMD' => [
            'AMD',
            'Dram Armenia',
        ],
        'ANG' => [
            'ANG',
            'Guilder Antilles yr Iseldiroedd',
        ],
        'AOA' => [
            'AOA',
            'Kwanza Angola',
        ],
        'AOK' => [
            'AOK',
            'Kwanza Angola (1977–1991)',
        ],
        'AON' => [
            'AON',
            'Kwanza Newydd Angola (1990–2000)',
        ],
        'AOR' => [
            'AOR',
            'Kwanza Ailgymhwysedig Angola (1995–1999)',
        ],
        'ARA' => [
            'ARA',
            'Austral yr Ariannin',
        ],
        'ARL' => [
            'ARL',
            'Peso Ley yr Ariannin (1970–1983)',
        ],
        'ARM' => [
            'ARM',
            'Peso yr Ariannin (1881–1970)',
        ],
        'ARP' => [
            'ARP',
            'Peso yr Ariannin (1983–1985)',
        ],
        'ARS' => [
            'ARS',
            'Peso yr Ariannin',
        ],
        'ATS' => [
            'ATS',
            'Swllt Awstria',
        ],
        'AUD' => [
            'A$',
            'Doler Awstralia',
        ],
        'AWG' => [
            'AWG',
            'Fflorin Aruba',
        ],
        'AZM' => [
            'AZM',
            'Manat Azerbaijan (1993–2006)',
        ],
        'AZN' => [
            'AZN',
            'Manat Azerbaijan',
        ],
        'BAM' => [
            'BAM',
            'Marc Trosadwy Bosnia a Hercegovina',
        ],
        'BBD' => [
            'BBD',
            'Doler Barbados',
        ],
        'BDT' => [
            'BDT',
            'Taka Bangladesh',
        ],
        'BEC' => [
            'BEC',
            'Ffranc Gwlad Belg (arnewidiol)',
        ],
        'BEF' => [
            'BEF',
            'Ffranc Gwlad Belg',
        ],
        'BEL' => [
            'BEL',
            'Ffranc Gwlad Belg (ariannol)',
        ],
        'BGM' => [
            'BGM',
            'Lev Sosialaidd Bwlgaria',
        ],
        'BGN' => [
            'BGN',
            'Lev Bwlgaria',
        ],
        'BGO' => [
            'BGO',
            'Lev Bwlgaria (1879–1952)',
        ],
        'BHD' => [
            'BHD',
            'Dinar Bahrain',
        ],
        'BIF' => [
            'BIF',
            'Ffranc Burundi',
        ],
        'BMD' => [
            'BMD',
            'Doler Bermuda',
        ],
        'BND' => [
            'BND',
            'Doler Brunei',
        ],
        'BOB' => [
            'BOB',
            'Boliviano Bolifia',
        ],
        'BOL' => [
            'BOL',
            'Boliviano Bolifia (1863–1963)',
        ],
        'BOP' => [
            'BOP',
            'Peso Bolifia',
        ],
        'BOV' => [
            'BOV',
            'Mvdol Bolifia',
        ],
        'BRB' => [
            'BRB',
            'Cruzeiro Newydd Brasil (1967–1986)',
        ],
        'BRC' => [
            'BRC',
            'Cruzado Brasil (1986–1989)',
        ],
        'BRE' => [
            'BRE',
            'Cruzeiro Brasil (1990–1993)',
        ],
        'BRL' => [
            'R$',
            'Real Brasil',
        ],
        'BRN' => [
            'BRN',
            'Cruzado Newydd Brasil (1989–1990)',
        ],
        'BRR' => [
            'BRR',
            'Cruzeiro Brasil (1993–1994)',
        ],
        'BRZ' => [
            'BRZ',
            'Cruzeiro Brasil (1942–1967)',
        ],
        'BSD' => [
            'BSD',
            'Doler y Bahamas',
        ],
        'BTN' => [
            'BTN',
            'Ngultrum Bhutan',
        ],
        'BUK' => [
            'BUK',
            'Kyat Byrma',
        ],
        'BWP' => [
            'BWP',
            'Pula Botswana',
        ],
        'BYN' => [
            'BYN',
            'Rwbl Belarws',
        ],
        'BYR' => [
            'BYR',
            'Rwbl Belarws (2000–2016)',
        ],
        'BZD' => [
            'BZD',
            'Doler Belize',
        ],
        'CAD' => [
            'CA$',
            'Doler Canada',
        ],
        'CDF' => [
            'CDF',
            'Ffranc Congo',
        ],
        'CHE' => [
            'CHE',
            'Ewro WIR',
        ],
        'CHF' => [
            'CHF',
            'Ffranc y Swistir',
        ],
        'CHW' => [
            'CHW',
            'Ffranc WIR',
        ],
        'CLE' => [
            'CLE',
            'Escudo Chile',
        ],
        'CLF' => [
            'CLF',
            'Uned Cyfrifo Chile (UF)',
        ],
        'CLP' => [
            'CLP',
            'Peso Chile',
        ],
        'CNH' => [
            'CNH',
            'Yuan Tsieina (ar y môr)',
        ],
        'CNX' => [
            'CNX',
            'Doler Banc Pobl Tsieina',
        ],
        'CNY' => [
            'CN¥',
            'Yuan Tsieina',
        ],
        'COP' => [
            'COP',
            'Peso Colombia',
        ],
        'COU' => [
            'COU',
            'Uned Gwir Werth Colombia',
        ],
        'CRC' => [
            'CRC',
            'Colón Costa Rica',
        ],
        'CUC' => [
            'CUC',
            'Peso Trosadwy Ciwba',
        ],
        'CUP' => [
            'CUP',
            'Peso Ciwba',
        ],
        'CVE' => [
            'CVE',
            'Esgwdo Cabo Verde',
        ],
        'CYP' => [
            'CYP',
            'Punt Cyprus',
        ],
        'CZK' => [
            'CZK',
            'Koruna’r Weriniaeth Tsiec',
        ],
        'DDM' => [
            'DDM',
            'Marc Dwyrain yr Almaen',
        ],
        'DEM' => [
            'DEM',
            'Marc yr Almaen',
        ],
        'DJF' => [
            'DJF',
            'Ffranc Djibouti',
        ],
        'DKK' => [
            'DKK',
            'Krone Denmarc',
        ],
        'DOP' => [
            'DOP',
            'Peso Gweriniaeth Dominica',
        ],
        'DZD' => [
            'DZD',
            'Dinar Algeria',
        ],
        'ECS' => [
            'ECS',
            'Sucre Ecuador',
        ],
        'ECV' => [
            'ECV',
            'Uned Gwerth Gyson Ecuador',
        ],
        'EEK' => [
            'EEK',
            'Kroon Estonia',
        ],
        'EGP' => [
            'EGP',
            'Punt Yr Aifft',
        ],
        'ERN' => [
            'ERN',
            'Nakfa Eritrea',
        ],
        'ETB' => [
            'ETB',
            'Birr Ethiopia',
        ],
        'EUR' => [
            '€',
            'Ewro',
        ],
        'FIM' => [
            'FIM',
            'Markka’r Ffindir',
        ],
        'FJD' => [
            'FJD',
            'Doler Ffiji',
        ],
        'FKP' => [
            'FKP',
            'Punt Ynysoedd Falkland/Malvinas',
        ],
        'FRF' => [
            'FRF',
            'Ffranc Ffrainc',
        ],
        'GBP' => [
            '£',
            'Punt Prydain',
        ],
        'GEK' => [
            'GEK',
            'Kupon Larit Georgia',
        ],
        'GEL' => [
            'GEL',
            'Lari Georgia',
        ],
        'GHC' => [
            'GHC',
            'Cedi Ghana (1979–2007)',
        ],
        'GHS' => [
            'GHS',
            'Cedi Ghana',
        ],
        'GIP' => [
            'GIP',
            'Punt Gibraltar',
        ],
        'GMD' => [
            'GMD',
            'Dalasi Gambia',
        ],
        'GNF' => [
            'GNF',
            'Ffranc Guinée',
        ],
        'GNS' => [
            'GNS',
            'Syli Guinée',
        ],
        'GQE' => [
            'GQE',
            'Ekwele Guinea Gyhydeddol',
        ],
        'GTQ' => [
            'GTQ',
            'Quetzal Guatemala',
        ],
        'GWP' => [
            'GWP',
            'Peso Guiné-Bissau',
        ],
        'GYD' => [
            'GYD',
            'Doler Guyana',
        ],
        'HKD' => [
            'HK$',
            'Doler Hong Kong',
        ],
        'HNL' => [
            'HNL',
            'Lempira Honduras',
        ],
        'HRK' => [
            'HRK',
            'Kuna Croatia',
        ],
        'HTG' => [
            'HTG',
            'Gourde Haiti',
        ],
        'HUF' => [
            'HUF',
            'Fforint Hwngari',
        ],
        'IDR' => [
            'IDR',
            'Rupiah Indonesia',
        ],
        'IEP' => [
            'IEP',
            'Punt Iwerddon',
        ],
        'ILP' => [
            'ILP',
            'Punt Israel',
        ],
        'ILR' => [
            'ILR',
            'Shegel Israel (1980–1985)',
        ],
        'ILS' => [
            '₪',
            'Shegel Newydd Israel',
        ],
        'INR' => [
            '₹',
            'Rwpî India',
        ],
        'IQD' => [
            'IQD',
            'Dinar Irac',
        ],
        'IRR' => [
            'IRR',
            'Rial Iran',
        ],
        'ISJ' => [
            'ISJ',
            'Króna Gwlad yr Iâ (1918 – 1981)',
        ],
        'ISK' => [
            'ISK',
            'Króna Gwlad yr Iâ',
        ],
        'JMD' => [
            'JMD',
            'Doler Jamaica',
        ],
        'JOD' => [
            'JOD',
            'Dinar Gwlad yr Iorddonen',
        ],
        'JPY' => [
            'JP¥',
            'Yen Japan',
        ],
        'KES' => [
            'KES',
            'Swllt Kenya',
        ],
        'KGS' => [
            'KGS',
            'Som Kyrgyzstan',
        ],
        'KHR' => [
            'KHR',
            'Riel Cambodia',
        ],
        'KMF' => [
            'KMF',
            'Ffranc Comoros',
        ],
        'KPW' => [
            'KPW',
            'Won Gogledd Corea',
        ],
        'KRH' => [
            'KRH',
            'Hwan De Corea (1953–1962)',
        ],
        'KRO' => [
            'KRO',
            'Won De Corea (1945–1953)',
        ],
        'KRW' => [
            'KRW',
            'Won De Corea',
        ],
        'KWD' => [
            'KWD',
            'Dinar Kuwait',
        ],
        'KYD' => [
            'KYD',
            'Doler Ynysoedd Cayman',
        ],
        'KZT' => [
            'KZT',
            'Tenge Kazakstan',
        ],
        'LAK' => [
            'LAK',
            'Kip Laos',
        ],
        'LBP' => [
            'LBP',
            'Punt Libanus',
        ],
        'LKR' => [
            'LKR',
            'Rwpî Sri Lanka',
        ],
        'LRD' => [
            'LRD',
            'Doler Liberia',
        ],
        'LSL' => [
            'LSL',
            'Loti Lesotho',
        ],
        'LTL' => [
            'LTL',
            'Litas Lithwania',
        ],
        'LTT' => [
            'LTT',
            'Talonas Lithwania',
        ],
        'LUF' => [
            'LUF',
            'Ffranc Lwcsembwrg',
        ],
        'LVL' => [
            'LVL',
            'Lats Latfia',
        ],
        'LVR' => [
            'LVR',
            'Rwbl Latfia',
        ],
        'LYD' => [
            'LYD',
            'Dinar Libya',
        ],
        'MAD' => [
            'MAD',
            'Dirham Moroco',
        ],
        'MAF' => [
            'MAF',
            'Ffranc Moroco',
        ],
        'MCF' => [
            'MCF',
            'Ffranc Monaco',
        ],
        'MDL' => [
            'MDL',
            'Leu Moldofa',
        ],
        'MGA' => [
            'MGA',
            'Ariary Madagascar',
        ],
        'MGF' => [
            'MGF',
            'Ffranc Madagascar',
        ],
        'MKD' => [
            'MKD',
            'Denar Macedonia',
        ],
        'MLF' => [
            'MLF',
            'Ffranc Mali',
        ],
        'MMK' => [
            'MMK',
            'Kyat Myanmar',
        ],
        'MNT' => [
            'MNT',
            'Tugrik Mongolia',
        ],
        'MOP' => [
            'MOP',
            'pataca Macau',
        ],
        'MRO' => [
            'MRO',
            'Ouguiya Mauritania (1973–2017)',
        ],
        'MRU' => [
            'MRU',
            'Ouguiya Mauritania',
        ],
        'MUR' => [
            'MUR',
            'Rwpî Mauritius',
        ],
        'MVP' => [
            'MVP',
            'Rwpî’r Maldives (1947–1981)',
        ],
        'MVR' => [
            'MVR',
            'Rufiyaa’r Maldives',
        ],
        'MWK' => [
            'MWK',
            'Kwacha Malawi',
        ],
        'MXN' => [
            'MX$',
            'Peso Mecsico',
        ],
        'MXP' => [
            'MXP',
            'Peso Arian México (1861–1992)',
        ],
        'MXV' => [
            'MXV',
            'Uned Fuddsoddi México',
        ],
        'MYR' => [
            'MYR',
            'Ringgit Malaysia',
        ],
        'MZE' => [
            'MZE',
            'Escudo Mozambique',
        ],
        'MZM' => [
            'MZM',
            'Metical Mozambique (1980–2006)',
        ],
        'MZN' => [
            'MZN',
            'Metical Mozambique',
        ],
        'NAD' => [
            'NAD',
            'Doler Namibia',
        ],
        'NGN' => [
            'NGN',
            'Naira Nigeria',
        ],
        'NIC' => [
            'NIC',
            'Córdoba Nicaragua (1988–1991)',
        ],
        'NIO' => [
            'NIO',
            'Cordoba Nicaragwa',
        ],
        'NLG' => [
            'NLG',
            'Guilder yr Iseldiroedd',
        ],
        'NOK' => [
            'NOK',
            'Krone Norwy',
        ],
        'NPR' => [
            'NPR',
            'Rwpî Nepal',
        ],
        'NZD' => [
            'NZ$',
            'Doler Seland Newydd',
        ],
        'OMR' => [
            'OMR',
            'Rial Oman',
        ],
        'PAB' => [
            'PAB',
            'Balboa Panama',
        ],
        'PEI' => [
            'PEI',
            'Inti Periw',
        ],
        'PEN' => [
            'PEN',
            'Sol Periw',
        ],
        'PES' => [
            'PES',
            'Sol Periw (1863–1965)',
        ],
        'PGK' => [
            'PGK',
            'Kina Papua Guinea Newydd',
        ],
        'PHP' => [
            'PHP',
            'Peso Philipinas',
        ],
        'PKR' => [
            'PKR',
            'Rwpî Pacistan',
        ],
        'PLN' => [
            'PLN',
            'Zloty Gwlad Pwyl',
        ],
        'PYG' => [
            'PYG',
            'Guarani Paraguay',
        ],
        'QAR' => [
            'QAR',
            'Rial Qatar',
        ],
        'RHD' => [
            'RHD',
            'Doler Rhodesia',
        ],
        'RON' => [
            'RON',
            'Leu Rwmania',
        ],
        'RSD' => [
            'RSD',
            'Dinar Serbia',
        ],
        'RUB' => [
            'RUB',
            'Rwbl Rwsia',
        ],
        'RWF' => [
            'RWF',
            'Ffranc Rwanda',
        ],
        'SAR' => [
            'SAR',
            'Riyal Saudi Arabia',
        ],
        'SBD' => [
            'SBD',
            'Doler Ynysoedd Solomon',
        ],
        'SCR' => [
            'SCR',
            'Rwpî Seychelles',
        ],
        'SDD' => [
            'SDD',
            'Dinar Sudan (1992–2007)',
        ],
        'SDG' => [
            'SDG',
            'Punt Sudan',
        ],
        'SDP' => [
            'SDP',
            'Punt Sudan (1957–1998)',
        ],
        'SEK' => [
            'SEK',
            'Krona Sweden',
        ],
        'SGD' => [
            'SGD',
            'Doler Singapore',
        ],
        'SHP' => [
            'SHP',
            'Punt St Helena',
        ],
        'SLE' => [
            'SLE',
            'Leone Sierra Leone',
        ],
        'SLL' => [
            'SLL',
            'Leone Sierra Leone (1964—2022)',
        ],
        'SOS' => [
            'SOS',
            'Swllt Somalia',
        ],
        'SRD' => [
            'SRD',
            'Doler Surinam',
        ],
        'SRG' => [
            'SRG',
            'Guilder Surinam',
        ],
        'SSP' => [
            'SSP',
            'Punt De Sudan',
        ],
        'STD' => [
            'STD',
            'Dobra São Tomé a Príncipe (1977–2017)',
        ],
        'STN' => [
            'STN',
            'Dobra São Tomé a Príncipe',
        ],
        'SVC' => [
            'SVC',
            'Colón El Salvador',
        ],
        'SYP' => [
            'SYP',
            'Punt Syria',
        ],
        'SZL' => [
            'SZL',
            'Lilangeni Gwlad Swazi',
        ],
        'THB' => [
            '฿',
            'Baht Gwlad Thai',
        ],
        'TJR' => [
            'TJR',
            'Rwbl Tajikistan',
        ],
        'TJS' => [
            'TJS',
            'Somoni Tajikistan',
        ],
        'TMM' => [
            'TMM',
            'Manat Turkmenistan (1993–2009)',
        ],
        'TMT' => [
            'TMT',
            'Manat Turkmenistan',
        ],
        'TND' => [
            'TND',
            'Dinar Tunisia',
        ],
        'TOP' => [
            'TOP',
            'Paʻanga Tonga',
        ],
        'TPE' => [
            'TPE',
            'Escudo Timor',
        ],
        'TRL' => [
            'TRL',
            'Lira Twrci (1922–2005)',
        ],
        'TRY' => [
            'TRY',
            'Lira Twrci',
        ],
        'TTD' => [
            'TTD',
            'Doler Trinidad a Tobago',
        ],
        'TWD' => [
            'NT$',
            'Doler Newydd Taiwan',
        ],
        'TZS' => [
            'TZS',
            'Swllt Tanzania',
        ],
        'UAH' => [
            'UAH',
            'Hryvnia Wcráin',
        ],
        'UGS' => [
            'UGS',
            'Swllt Uganda (1966–1987)',
        ],
        'UGX' => [
            'UGX',
            'Swllt Uganda',
        ],
        'USD' => [
            'US$',
            'Doler UDA',
        ],
        'USN' => [
            'USN',
            'Doler UDA (y diwrnod nesaf)',
        ],
        'USS' => [
            'USS',
            'Doler UDA (yr un diwrnod)',
        ],
        'UYP' => [
            'UYP',
            'Peso Uruguay (1975–1993)',
        ],
        'UYU' => [
            'UYU',
            'Peso Uruguay',
        ],
        'UZS' => [
            'UZS',
            'Som Uzbekistan',
        ],
        'VEB' => [
            'VEB',
            'Bolívar Venezuela (1871–2008)',
        ],
        'VEF' => [
            'VEF',
            'Bolívar Venezuela (2008–2018)',
        ],
        'VES' => [
            'VES',
            'Bolívar Venezuela',
        ],
        'VND' => [
            '₫',
            'Dong Fietnam',
        ],
        'VNN' => [
            'VNN',
            'Dong Fietnam (1978–1985)',
        ],
        'VUV' => [
            'VUV',
            'Vatu Vanuatu',
        ],
        'WST' => [
            'WST',
            'Tala Samoa',
        ],
        'XAF' => [
            'FCFA',
            'Ffranc CFA Canol Affrica',
        ],
        'XCD' => [
            'EC$',
            'Doler Dwyrain y Caribî',
        ],
        'XEU' => [
            'XEU',
            'Uned Arian Cyfred Ewropeaidd',
        ],
        'XOF' => [
            'F CFA',
            'Ffranc CFA Gorllewin Affrica',
        ],
        'XPF' => [
            'CFPF',
            'Ffranc CFP',
        ],
        'YDD' => [
            'YDD',
            'Dinar Yemen',
        ],
        'YER' => [
            'YER',
            'Rial Yemen',
        ],
        'ZAL' => [
            'ZAL',
            'Rand (ariannol) De Affrica',
        ],
        'ZAR' => [
            'ZAR',
            'Rand De Affrica',
        ],
        'ZMK' => [
            'ZMK',
            'Kwacha Zambia (1968–2012)',
        ],
        'ZMW' => [
            'ZMW',
            'Kwacha Zambia',
        ],
        'ZRN' => [
            'ZRN',
            'Zaire Newydd Zaire (1993–1998)',
        ],
        'ZRZ' => [
            'ZRZ',
            'Zaire Zaire (1971–1993)',
        ],
        'ZWD' => [
            'ZWD',
            'Doler Zimbabwe (1980–2008)',
        ],
        'ZWL' => [
            'ZWL',
            'Doler Zimbabwe (2009)',
        ],
        'ZWR' => [
            'ZWR',
            'Doler Zimbabwe (2008)',
        ],
    ],
];
