<?php

return [
    'Names' => [
        'af' => 'Afreeki',
        'bgc' => 'Hariyaanvi',
        'bn' => 'Bangla',
        'bo' => 'Tibbati',
        'ckb' => 'Kurdish, Sorani',
        'crh' => 'Crimean Turkish',
        'fa' => 'Faarsi',
        'ff' => 'Fulah',
        'lah' => 'Lahnda',
        'mic' => 'Mi\'kmaq',
        'mus' => 'Muscogee',
        'nan' => 'Min Nan',
        'nb' => 'Norwegian Bokmal',
        'ug' => 'Uighur',
        'wal' => 'walamo',
    ],
    'LocalizedNames' => [
        'nds_NL' => 'Low Saxon',
    ],
];
