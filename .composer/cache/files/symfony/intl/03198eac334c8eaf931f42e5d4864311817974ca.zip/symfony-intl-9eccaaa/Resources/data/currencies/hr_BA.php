<?php

return [
    'Names' => [
        'BAM' => [
            'KM',
            'konvertibilna marka',
        ],
    ],
];
